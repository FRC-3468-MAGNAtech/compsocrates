// FILE: app/components/Sidebar.tsx
// ADD THEME PICKER TO SETTINGS - Just add this to your settings dropdown

// At the top with other imports:
import ThemePicker from "@/app/components/ThemePicker";

// In the settings dropdown (around line 230-260), add ThemePicker:

{showSettings && (
  <>
    <div
      className="fixed inset-0 z-40"
      onClick={() => setShowSettings(false)}
    />
    
    <div
      className={`
        absolute bottom-full mb-2 bg-white rounded-lg shadow-xl border border-gray-200 z-50
        ${collapsed ? "left-full ml-2 w-48" : "left-2 right-2"}
      `}
    >
      <Link
        href={`/profile/${userData.uid}`}
        className="block px-4 py-2 hover:bg-gray-100 text-sm text-gray-700 rounded-t-lg"
        onClick={() => setShowSettings(false)}
      >
        View Profile
      </Link>
      <Link
        href="/account"
        className="block px-4 py-2 hover:bg-gray-100 text-sm text-gray-700"
        onClick={() => setShowSettings(false)}
      >
        Account Settings
      </Link>
      
      {/* ADD THIS: */}
      <div className="border-t border-gray-200">
        <ThemePicker />
      </div>
      
      <button
        onClick={async () => {
          await logOut();
          setShowSettings(false);
        }}
        className="w-full text-left px-4 py-2 hover:bg-gray-100 text-sm text-red-600 rounded-b-lg border-t border-gray-200"
      >
        Log Out
      </button>
    </div>
  </>
)}

// That's it! Just add ThemePicker between Account Settings and Log Out
