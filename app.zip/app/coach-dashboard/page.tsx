// FILE: app/coach-dashboard/page.tsx
// COMPLETE REWRITE - Scout counter with input, lead scouts counted

"use client";

import { useState, useEffect } from "react";
import { collection, query, where, getDocs } from "firebase/firestore";
import { db } from "@/app/firebase";
import ProtectedRoute from "@/app/components/ProtectedRoute";
import Sidebar from "@/app/components/Sidebar";
import { useAuth } from "@/app/AuthContext";
import LoadingSpinner from "@/app/components/LoadingSpinner";
import { Users, Target, Calendar, TrendingUp } from "lucide-react";
import { isEventActive, getCurrentEvent } from "@/app/utils/eventDates";

function CoachDashboardContent() {
  const { userData } = useAuth();
  const [scoutCount, setScoutCount] = useState(0);
  const [expectedScouts, setExpectedScouts] = useState(() => {
    if (typeof window !== 'undefined') {
      return parseInt(localStorage.getItem('expectedScouts') || '8');
    }
    return 8;
  });
  const [verifiedCount, setVerifiedCount] = useState(0);
  const [recentEntries, setRecentEntries] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('expectedScouts', expectedScouts.toString());
    }
  }, [expectedScouts]);

  useEffect(() => {
    loadDashboardData();
  }, [userData?.teamId]);

  async function loadDashboardData() {
    if (!userData?.teamId) return;

    try {
      // Get all team members
      const usersQuery = query(
        collection(db, "users"),
        where("teamId", "==", userData.teamId)
      );
      const usersSnap = await getDocs(usersQuery);
      const allUsers = usersSnap.docs.map(doc => ({ uid: doc.id, ...doc.data() }));

      // Count scouts + lead scouts
      const scouts = allUsers.filter(u => 
        u.role === "scout" || (u.role === "coach" && u.specialRole === "Lead Scout")
      );
      setScoutCount(scouts.length);

      // Get practice sessions
      const sessionsSnap = await getDocs(collection(db, "practiceSessions"));
      const sessions = sessionsSnap.docs.map(doc => doc.data());

      // Count verified scouts (80%+ accuracy)
      const scoutAccuracies = scouts.map(scout => {
        const scoutSessions = sessions.filter(s => s.scoutId === scout.uid);
        if (scoutSessions.length === 0) return 0;
        return Math.round(
          scoutSessions.reduce((sum, s) => sum + (s.accuracy || 0), 0) / scoutSessions.length
        );
      });
      setVerifiedCount(scoutAccuracies.filter(a => a >= 80).length);

      // Get recent scouting entries (last 7 days)
      const entriesSnap = await getDocs(collection(db, "scouting"));
      const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
      const recent = entriesSnap.docs
        .map(doc => doc.data())
        .filter(e => e.timestamp && e.timestamp > sevenDaysAgo);
      setRecentEntries(recent.length);

    } catch (error) {
      console.error("Error loading dashboard:", error);
    } finally {
      setLoading(false);
    }
  }

  const currentEvent = getCurrentEvent();
  const eventActive = isEventActive();

  if (loading) {
    return (
      <div className="flex h-screen bg-gray-100">
        <Sidebar />
        <div className="flex-1 flex items-center justify-center">
          <LoadingSpinner message="Loading dashboard..." />
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />
      <div className="flex-1 overflow-y-auto">
        <div className="p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2" style={{ color: "#c42221" }}>
              Coach Dashboard
            </h1>
            <p className="text-gray-600">
              Team overview and scouting readiness
            </p>
          </div>

          {/* Event Status */}
          <div className={`rounded-xl shadow-md p-6 mb-8 ${eventActive ? 'bg-green-50 border-2 border-green-500' : 'bg-yellow-50 border-2 border-yellow-500'}`}>
            <div className="flex items-center gap-3">
              <Calendar size={32} className={eventActive ? 'text-green-600' : 'text-yellow-600'} />
              <div>
                <h2 className="text-xl font-bold">
                  {eventActive ? `🟢 ${currentEvent?.name} - ACTIVE` : '🟡 No Active Event'}
                </h2>
                {currentEvent && (
                  <p className="text-sm text-gray-700 mt-1">
                    {currentEvent.location} • {new Date(currentEvent.startDate).toLocaleDateString()} - {new Date(currentEvent.endDate).toLocaleDateString()}
                  </p>
                )}
                {!eventActive && currentEvent && (
                  <p className="text-sm text-gray-700 mt-1">
                    Next event starts in {Math.ceil((currentEvent.startDate - Date.now()) / (1000 * 60 * 60 * 24))} days
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Scouts Ready */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <div className="flex items-center gap-3 mb-3">
                <Users size={24} style={{ color: "#c42221" }} />
                <h3 className="font-semibold text-gray-700">Scouts Ready</h3>
              </div>
              <p className="text-4xl font-bold mb-2" style={{ color: "#c42221" }}>
                {scoutCount}/{expectedScouts}
              </p>
              <div className="mt-3">
                <label className="block text-xs text-gray-600 mb-1">Expected Scouts</label>
                <input
                  type="number"
                  value={expectedScouts}
                  onChange={(e) => setExpectedScouts(Math.max(1, Number(e.target.value)))}
                  className="w-full border rounded px-2 py-1 text-sm"
                  min="1"
                />
              </div>
            </div>

            {/* Verified Scouts */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <div className="flex items-center gap-3 mb-3">
                <Target size={24} className="text-green-600" />
                <h3 className="font-semibold text-gray-700">Verified</h3>
              </div>
              <p className="text-4xl font-bold text-green-600">{verifiedCount}</p>
              <p className="text-sm text-gray-500 mt-2">80%+ accuracy</p>
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <div className="flex items-center gap-3 mb-3">
                <TrendingUp size={24} className="text-blue-600" />
                <h3 className="font-semibold text-gray-700">Recent Activity</h3>
              </div>
              <p className="text-4xl font-bold text-blue-600">{recentEntries}</p>
              <p className="text-sm text-gray-500 mt-2">Entries (last 7 days)</p>
            </div>

            {/* Team Info */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <div className="flex items-center gap-3 mb-3">
                <Users size={24} className="text-purple-600" />
                <h3 className="font-semibold text-gray-700">Team</h3>
              </div>
              <p className="text-2xl font-bold text-purple-600">{userData?.teamId || 'N/A'}</p>
              <p className="text-sm text-gray-500 mt-2">{userData?.displayName}</p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="mt-8 bg-white rounded-xl shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
            <div className="grid md:grid-cols-3 gap-4">
              <a
                href="/scout-accuracy"
                className="p-4 border-2 rounded-lg hover:border-red-600 transition-colors"
              >
                <h3 className="font-semibold mb-2">Check Scout Accuracy</h3>
                <p className="text-sm text-gray-600">View practice session results</p>
              </a>
              <a
                href="/team-management"
                className="p-4 border-2 rounded-lg hover:border-red-600 transition-colors"
              >
                <h3 className="font-semibold mb-2">Manage Team</h3>
                <p className="text-sm text-gray-600">Add scouts, assign roles</p>
              </a>
              <a
                href="/analytics"
                className="p-4 border-2 rounded-lg hover:border-red-600 transition-colors"
              >
                <h3 className="font-semibold mb-2">View Analytics</h3>
                <p className="text-sm text-gray-600">Analyze scouting data</p>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function CoachDashboardPage() {
  return (
    <ProtectedRoute requireAuth={true} allowedRoles={["coach"]}>
      <CoachDashboardContent />
    </ProtectedRoute>
  );
}
